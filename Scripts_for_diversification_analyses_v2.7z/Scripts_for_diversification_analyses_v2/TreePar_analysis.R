library('TreePar')
setwd("***") ##set your work path
phy <- read.tree("file_name")
x <- sort(getx(phy), decreasing=TRUE)
sink("file_name")
resingroup <- bd.shifts.optim(x, sampling=c(0.59,0.5,0.5,0.5,0.5,0.5), grid=0.1, start=0, end=4.35, yule=FALSE, ME=FALSE, all=FALSE, posdiv=FALSE)[[2]]
sink()

sink("file_name")
resingroup5 <- bd.shifts.optim(x, sampling=c(0.59,0.5,0.5,0.5,0.5,0.5), grid=0.1, start=0, end=4.35, yule=FALSE, ME=TRUE, all=FALSE, posdiv=FALSE)[[2]]
sink()
