#########################################
###### PHYLOGENETIC PATH ANALYSES #######
#########################################
## This R script is modified from Dellinger et al (2024) by Lihua Yang
##Dellinger et al. 2024. The Sequential Direct and Indirect Effects of Mountain Uplift, Climatic Niche, and Floral Trait Evolution on Diversifcation Dynamics in an Andean Plant Clade. Syst. Biol.

#https://cran.r-project.org/web/packages/phylopath/vignettes/intro_to_phylopath.html
#https://cran.r-project.org/web/packages/motmot/vignettes/motmot.html#models-of-trait-evolution


#to infer causal relationships of niche variables on current speciation rates

library(ape)
library(phytools)
library(geiger)
library(phylopath)

setwd("set your work path")

#############
# 1) read in tree and data
#############

mytree <- read.tree("tree file")
mydata <- read.csv("input data", row.names = 1)
##rownames(mydata) <- mydata$species

#compares names between the tree and the data to list any discrepancies
comparison <- name.check(phy=mytree, data=mydata)
comparison

##convert binary data to a factor
mydata$PS <- as.character(mydata$PS)
mydata$CC <- as.character(mydata$CC)
mydata$ST <- as.character(mydata$ST)
mydata$HB <- as.character(mydata$HB)

#str(mydata)
#colnames(mydata)[2]<-"OV" #geo_overlap
#colnames(mydata)[3]<-"PS" #pistil_shap
#colnames(mydata)[4]<-"CC" #corolla_color
#colnames(mydata)[5]<-"ST" #stem
#colnames(mydata)[6]<-"HB" #habitat
#colnames(mydata)[7]<-"CM1" #climate_PCA1
#colnames(mydata)[8]<-"CM2" #climate_PCA2
#colnames(mydata)[9]<-"CM3" #climate_PCA3
#colnames(mydata)[10]<-"DR" #netdiv_rate

#############
# 2) construct the hypotheses
#############

models <- define_model_set(
  M01 = c(DR~CM1+CM2+CM3+HB),
  M02 = c(DR~PS+CC+ST),
  M03 = c(DR~rOV),
  M04 = c(DR~CM1+CM2+CM3+HB, DR~PS+CC+ST, DR~rOV),
  M05 = c(DR~rOV, rOV~PS+CC+ST),
  M06 = c(DR~rOV, rOV~CM1+CM2+CM3+HB),
  M07 = c(DR~PS+CC+ST, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB),
  M08 = c(DR~PS+CC+ST, PS~rOV, CC~rOV, ST~rOV),
  M09 = c(DR~PS+CC+ST, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB, PS~rOV, CC~rOV, ST~rOV),
  M10 = c(DR~rOV, rOV~PS+CC+ST, rOV~CM1+CM2+CM3+HB),
  M11 = c(DR~rOV, rOV~PS+CC+ST, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB),
  M12 = c(DR~PS+CC+ST, PS~rOV, CC~rOV, ST~rOV, rOV~CM1+CM2+CM3+HB),
  M13 = c(DR~PS+CC+ST, DR~CM1+CM2+CM3+HB, PS~rOV, CC~rOV, ST~rOV, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB),
  M14 = c(DR~rOV, DR~CM1+CM2+CM3+HB, rOV~PS+CC+ST, rOV~CM1+CM2+CM3+HB),
  M15 = c(DR~rOV, DR~CM1+CM2+CM3+HB, DR~PS+CC+ST, PS~rOV, CC~rOV, ST~rOV, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB),
  M16 = c(DR~rOV, DR~CM1+CM2+CM3+HB, DR~PS+CC+ST, rOV~CM1+CM2+CM3+HB, rOV~PS+CC+ST),
  M17 = c(DR~rOV, DR~CM1+CM2+CM3+HB, DR~PS+CC+ST, PS~rOV, CC~rOV, ST~rOV, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB, rOV~CM1+CM2+CM3+HB),
  M18 = c(DR~rOV, DR~CM1+CM2+CM3+HB, DR~PS+CC+ST, rOV~CM1+CM2+CM3+HB, rOV~PS+CC+ST, PS~CM1+CM2+CM3+HB, CC~CM1+CM2+CM3+HB, ST~CM1+CM2+CM3+HB),
  .common = c()
)

#windows()
plot_model_set(models, algorithm = 'kk', text_size = 2, box_x = 2, box_y = 1, edge_width = 0.2, arrow = grid::arrow(type = "closed", 8, grid::unit(6, "points")))

#############
# 3) run the model
#############

#lambda model
result_lambda <- phylo_path(models, data = mydata, tree = mytree, method = 'logistic_MPLE', model="lambda", lower.bound=0, upper.bound=1)
#result_lambda  #M07 is best
sld <- summary(result_lambda) #a model does not have a good fit if the p-value is below 0.05!
#result_lambda$d_sep$M07$model #look at coefficients
write.table(sld, "phylopath_lambda_test20240726_DR_rOV.csv", sep = ",")
plot(sld)

##############
# 4) best model
##############

best_model_lambda <- best(result_lambda, boot=100)

#windows()
plot(best_model_lambda)

##############
# 5) average models
##############

#average the best-fit models and use those

#lambda
average_model_full_lambda <- average(result_lambda, cut_off=2, avg_method = "full", boot=100)
plot(average_model_full_lambda, algorithm = 'mds', curvature = 0.1)
plot(average_model_full_lambda)

##############
#6) plot confidence intervals
#make plot nicer
coef_plot(average_model_full_lambda, reverse_order = TRUE) + 
  ggplot2::coord_flip() + 
  ggplot2::theme_bw()
coef_plot(average_model_full_lambda, reverse_order = TRUE)

