import pandas as pd
import geopandas as gpd
from shapely.geometry import MultiPoint

df3 = pd.read_csv('filename.csv')
gdf3 = gpd.GeoDataFrame(geometry=df3.groupby('species').apply(
        lambda g: MultiPoint(gpd.points_from_xy(g['longitude'], g['latitude'], crs='EPSG:4326'))))
gdf3_2 = gdf3.convex_hull
gdf3_3 = gdf3_2.buffer(0.045)
gdf3_3.to_file('filename.shp')
