##install.packages('phyloclim')
library(phyloclim)
library(ape)

setwd("set your work path")
phylo <- read.tree("tree file")

data <- read.csv("datafile.csv", row.names = 1)

x <- age.range.correlation(phy = phylo, overlap = data, tri = "upper", n = 100)

plot(x$age.range.correlation, pch = 16, cex=1.5, col = "blue")
abline(x$linear.regression$coefficients, lty=2)

