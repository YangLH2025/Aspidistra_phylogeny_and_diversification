library("ape")
library("DDD")
setwd("set your work path")

phyloi <- read.tree("tree file") #If this does not work try with read.nexus()
missing.lineages <- 86 #You sampled the total diversity of the clade

brtsi <- as.numeric(branching.times(phyloi))
initi<-1+length(brtsi)+missing.lineages
resi<-10*(1+length(brtsi)+missing.lineages)
  
resDDD<-c()
  
  print("Linear dependence of speciation rate without extinction")
  DDD_1 <- dd_ML(brtsi, ddmodel=1, initparsopt=c(0.15,initi), idparsopt=c(1,3), idparsfix=c(2), parsfix=c(0), res=resi, missnumspec=missing.lineages, cond=1, btorph=1, soc=2)
  print(DDD_1)
  
  print("Linear dependence of speciation rate with extinction")
  DDD_2 <- dd_ML(brtsi, ddmodel=1, initparsopt=c(0.2,0.1,initi), idparsopt=c(1:3), res=resi, missnumspec=missing.lineages, cond=1, btorph=1, soc=2)
  print(DDD_2)
  
  print("Exponential dependence of speciation rate with extinction")
  DDD_3 <- dd_ML(brtsi, ddmodel=2, initparsopt=c(0.2,0.1,initi), idparsopt=c(1:3), res=resi, missnumspec=missing.lineages, cond=1, btorph=1, soc=2)
  print(DDD_3)
  
  print("Linear dependence of extinction rate")
  DDD_4 <- dd_ML(brtsi, ddmodel=3, initparsopt=c(0.2,0.1,initi), idparsopt=c(1:3), res=resi, missnumspec=missing.lineages, cond=1, btorph=1, soc=2, optimmethod = 'simplex')
  print(DDD_4)
  
  print("Exponential dependence of extinction rate")
  DDD_5 <- dd_ML(brtsi, ddmodel=4, initparsopt=c(0.2,0.01,initi), idparsopt=c(1:3), res=resi, missnumspec=missing.lineages, cond=1, btorph=1, soc=2, optimmethod = 'simplex')
  print(DDD_5)
  
  print("diversity-independent diversification with constant speciation and extinction rate")
  null_1 <- bd_ML(brtsi, tdmodel=0, missnumspec=missing.lineages, cond=1, btorph=1, soc=2)
  print(null_1)
  
  #Results
  
  results <- matrix(NA,6,7)
  
  colnames(results) <- c("Model","NP","logL","AICc","Lambda","Mu","K")
  results[,1] <- c("DDL","DDL+E","DDX+E","DD+EL","DD+EX","null")
  
  #NP
  results[1,2] <- round(as.numeric(DDD_1[5]))
  results[2,2] <- round(as.numeric(DDD_2[5]))
  results[3,2] <- round(as.numeric(DDD_3[5]))
  results[4,2] <- round(as.numeric(DDD_4[5]))
  results[5,2] <- round(as.numeric(DDD_5[5]))
  results[6,2] <- round(as.numeric(null_1[6]))
  
  #logL
  results[1,3] <- round(as.numeric(DDD_1[4]),4)
  results[2,3] <- round(as.numeric(DDD_2[4]),4)
  results[3,3] <- round(as.numeric(DDD_3[4]),4)
  results[4,3] <- round(as.numeric(DDD_4[4]),4)
  results[5,3] <- round(as.numeric(DDD_5[4]),4)
  results[6,3] <- round(as.numeric(null_1[5]),4)
  
  # AICc
  results[1,4] <- round((2*(-round(as.numeric(DDD_1[4]),4))+2*round(as.numeric(DDD_1[5]))+(2*round(as.numeric(DDD_1[5]))*(round(as.numeric(DDD_1[5]))+1))/(Ntip(phyloi)-round(as.numeric(DDD_1[5]))-1)),3)
  results[2,4] <- round((2*(-round(as.numeric(DDD_2[4]),4))+2*round(as.numeric(DDD_2[5]))+(2*round(as.numeric(DDD_2[5]))*(round(as.numeric(DDD_2[5]))+1))/(Ntip(phyloi)-round(as.numeric(DDD_2[5]))-1)),3)
  results[3,4] <- round((2*(-round(as.numeric(DDD_3[4]),4))+2*round(as.numeric(DDD_3[5]))+(2*round(as.numeric(DDD_3[5]))*(round(as.numeric(DDD_3[5]))+1))/(Ntip(phyloi)-round(as.numeric(DDD_3[5]))-1)),3)
  results[4,4] <- round((2*(-round(as.numeric(DDD_4[4]),4))+2*round(as.numeric(DDD_4[5]))+(2*round(as.numeric(DDD_4[5]))*(round(as.numeric(DDD_4[5]))+1))/(Ntip(phyloi)-round(as.numeric(DDD_4[5]))-1)),3)
  results[5,4] <- round((2*(-round(as.numeric(DDD_5[4]),4))+2*round(as.numeric(DDD_5[5]))+(2*round(as.numeric(DDD_5[5]))*(round(as.numeric(DDD_5[5]))+1))/(Ntip(phyloi)-round(as.numeric(DDD_5[5]))-1)),3)
  results[6,4] <- round((2*(-round(as.numeric(null_1[5]),4))+2*round(as.numeric(null_1[6]))+(2*round(as.numeric(null_1[6]))*(round(as.numeric(null_1[6]))+1))/(Ntip(phyloi)-round(as.numeric(null_1[6]))-1)),3)
  
  #Lambda
  results[1,5] <- round(as.numeric(DDD_1[1]),4)
  results[2,5] <- round(as.numeric(DDD_2[1]),4)
  results[3,5] <- round(as.numeric(DDD_3[1]),4)
  results[4,5] <- round(as.numeric(DDD_4[1]),4)
  results[5,5] <- round(as.numeric(DDD_5[1]),4)
  results[6,5] <- round(as.numeric(null_1[1]),4)
  
  #Mu
  results[2,6] <- round(as.numeric(DDD_2[2]),5)
  results[3,6] <- round(as.numeric(DDD_3[2]),5)
  results[4,6] <- round(as.numeric(DDD_4[2]),5)
  results[5,6] <- round(as.numeric(DDD_5[2]),5)
  results[6,6] <- round(as.numeric(null_1[2]),5)
  
  #K
  results[1,7] <- round(as.numeric(DDD_1[3]),2)
  results[2,7] <- round(as.numeric(DDD_2[3]),2)
  results[3,7] <- round(as.numeric(DDD_3[3]),2)
  results[4,7] <- round(as.numeric(DDD_4[3]),2)
  results[5,7] <- round(as.numeric(DDD_5[3]),2)
  
  

  
  #resi<-list("Clade_age"=max(brtsi),"Clade_size"=as.numeric(FamilyBirdTrees[[i]][[2]]),"Taxon_sampling"=Ntip(phyloi),"missing_species"=missing.lineages,"DDL"=DDD_1,"DDL+E"=DDD_2,"DDX+E"=DDD_3,"DD+EL"=DDD_4,"DD+EX"=DDD_5)
  resi <- list("Clade_age"=max(brtsi),"Clade_size"=Ntip(phyloi)+missing.lineages,"Taxon_sampling"=Ntip(phyloi)/(Ntip(phyloi)+missing.lineages),"missing_species"=missing.lineages,"DDL"=DDD_1,"DDL+E"=DDD_2,"DDX+E"=DDD_3,"DD+EL"=DDD_4,"DD+EX"=DDD_5,"null"=null_1)
  
  resDDD<-c(resDDD,list(resi))

save(resDDD, file="filename.Rdata")
write.csv(results, file="filename.csv", quote=FALSE, row.names=FALSE)


# AIC weight
aics <- data.frame(c("DDL", "DDL+E", "DDX+E", "DD+EL","DD+EX","null"), 
                   c(-151.8089,-144.646,-169.0643,-167.044,-166.3989,-166.4123),
                   c(307.718,295.494,344.33,340.29,338.999,336.925), 
                   row.names = NULL)
colnames(aics) <- c("model", "loglik", "AICc")
aics <- aics[order(aics$AICc), ]
for(i in 1:dim(aics)[1]){ 
  aics$delta[i] <- aics$AICc[i] - aics$AICc[1]
} 
aics$W <- (exp(-0.5 * aics$delta) / sum(exp(-0.5 * aics$delta)))
aics
write.table(format(aics, digits = 5, scientific=FALSE), file="filename.txt", sep = "\t", row.names = FALSE, quote = FALSE)


