import sys
import geopandas as gpd

shp_file1 = sys.argv[1]
shp_file2 = sys.argv[2]
out_file1 = sys.argv[3]

df1 = gpd.read_file(shp_file1)
df2 = gpd.read_file(shp_file2)

inter = gpd.overlay(df1, df2, 'intersection')
inter_S = inter.area*111194.872221777*111194.872221777/1000000

outfile=open(out_file1,"w")
outfile.write(str(inter_S)+"\n")


