# This script tests 25 different models in the HiSSE, then, produces boxplots to observe differences.

library(phytools)
library(geiger)
library(hisse)
library(diversitree)
library(ape)

setwd("set your work path")
source("plot.hisse.states.PIES.R") ## the script (plot.hisse.states.PIES.R) is downloaded from Portik et al. (2019) Sexual Dichromatism Drives Diversification within a Major Radiation of African Amphibians. Systematic Biology 

#######################################################################
#read tree and data
mytree <- read.tree("tree file")
mydata <- read.csv("trait file", row.names = 1)

#######################################################################
#compares names between the tree and the data to list any discrepancies
comparison <- name.check(phy=mytree,data=mydata)
comparison

#######################################################################
# prune taxa that don't have data but are present in the tree
mytree <- drop.tip(mytree,comparison$tree_not_data)
#write.tree(mytree,"Sau_drop.tre")
#double check to make sure that taxa all match with tree and data
name.check(phy=mytree,data=mydata)
#comparison <- name.check(phy=mytree,data=mydata)

#######################################################################
# make a new dateframe of the states
states<- data.frame(rownames(mydata), mydata$pistil_shap_bistate)

#######################################################################
#Make q-rate matrices

TransMatMaker.old(hidden.states=TRUE)
trans.rates.hisse <- TransMatMaker.old(hidden.states=TRUE)
trans.rates.nodual <- ParDrop(trans.rates.hisse, c(3,5,8,10))

trans.rates.nodual.equalrates <- trans.rates.nodual
trans.rates.nodual.equalrates[!is.na(trans.rates.nodual.equalrates) & !trans.rates.nodual.equalrates == 0] = 1

trans.rates.bisse <- TransMatMaker.old(hidden.states=FALSE)
trans.rates.bisse.equal <- trans.rates.bisse
trans.rates.bisse.equal[!is.na(trans.rates.bisse.equal)] = 1

trans.rates.nodual.threerates <- trans.rates.nodual
to.change <- cbind(c(1,3), c(2,4))
trans.rates.nodual.threerates[to.change] <- 1
to.change <- cbind(c(2,4), c(1,3))
trans.rates.nodual.threerates[to.change] <- 2
to.change <- cbind(c(1,3,2,4), c(3,1,4,2))
trans.rates.nodual.threerates[to.change] <- 3

#Check rate matrices
trans.rates.bisse
trans.rates.bisse.equal

trans.rates.nodual
trans.rates.nodual.equalrates
trans.rates.nodual.threerates

#######################################################################

#Set prior on root

#For user-specified “root.p”, you should specify the probability for each state. If you are doing a hidden model, 
#there will be four states: 0A, 1A, 0B, 1B. So if you wanted to say the root had to be state 0, you would specify 
#“root.p = c(0.5, 0, 0.5, 0)”.
#Here I set a probability of 0 for dichromatism and 1 for monochromatism on the root, with good evidence.

##root_prior = c(0,1)
##root_prior_hidden = c(0, 0.5, 0, 0.5)
##root_prior_CID4 = c(0, 0.25, 0, 0.25, 0, 0.25, 0, 0.25)

#######################################################################
### FiSSE analysis
set.seed(152) # Set random-number seed to ensure reproducibility of simulation-based P-value

###################################################################################
#####run the full model with free r, e, and q, run 1
#full hisse model
cat("Full HiSSE Model, run 1 \n")
turnover.anc = c(1,2,3,4)
eps.anc = c(1,2,3,4)

pp01 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual, root.type = "herr_als", output.type="raw")

###################################################################################
###BiSSE model all free, run 2
cat("BiSSE model all free, run 2 \n")
turnover.anc = c(1,2,0,0)
eps.anc = c(1,2,0,0)

pp02 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=FALSE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.bisse, root.type = "herr_als", output.type="raw")

###################################################################################
###BiSSE model, e0=e1, run 3
cat("BiSSE model, e0=e1, run 3 \n")

turnover.anc = c(1,2,0,0)
eps.anc = c(1,1,0,0)

pp03 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=FALSE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.bisse, root.type = "herr_als", output.type="raw")

###################################################################################
###BiSSE model with equal q, run 4
cat("BiSSE model with equal q, run 4 \n")

turnover.anc = c(1,2,0,0)
eps.anc = c(1,2,0,0)

pp04 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=FALSE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.bisse.equal, root.type = "herr_als", output.type="raw")

###################################################################################
###BiSSE model with equal q and e0=e1, run 5
cat("BiSSE model with equal q and e0=e1, run 5 \n")

turnover.anc = c(1,2,0,0)
eps.anc = c(1,1,0,0)

pp05 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=FALSE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.bisse.equal, root.type = "herr_als", output.type="raw")

###################################################################################
#CID-2 model with equal q, run 6
#null two model, traits A and B have a diversification rate
cat("CID-2 model with equal q, run 6 \n")

turnover.anc = c(1,1,2,2)
eps.anc = c(1,1,2,2)

pp06 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#CID-2 model with equal q and e, run 7
#null two model, traits A and B have a diversification rate
cat("CID-2 model with equal q and e, run 7 \n")

turnover.anc = c(1,1,2,2)
eps.anc = c(1,1,1,1)

pp07 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
######CID-4 model, run 8
cat("CID-4 model, run 8 \n")

turnover.anc=rep(c(1,2,3,4),2)
eps.anc=rep(c(1,2,3,4),2)

pp08 <- hisse.null4.old(mytree, states, f=c(0.59,0.59), turnover.anc=turnover.anc, eps.anc=eps.anc, root.type = "herr_als", output.type="raw")

###################################################################################
######CID-4 model with equal e, run 9
cat("CID-4 model with equal e, run 9 \n")

turnover.anc = rep(c(1,2,3,4),2)
eps.anc = rep(c(1,1,1,1),2)

pp09 = hisse.null4.old(mytree, states, f=c(0.59,0.59), turnover.anc=turnover.anc, eps.anc=eps.anc, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r=free, e=free, and transition rates equal, run 10
#full hisse model
cat("run the full model with r=free, e=free, and transition rates equal, run 10 \n")
turnover.anc = c(1,2,3,4)
eps.anc = c(1,2,3,4)

pp10 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r=free, equal e and q, run 11
cat("run the full model with r=free, equal e and q, run 11 \n")

turnover.anc = c(1,2,3,4)
eps.anc = c(1,1,1,1)

pp11 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a=r0b, e0a=e1a=e0b, and equal q, run 12
cat("run the full model with r0a=r1a=r0b, e0a=e1a=e0b, and equal q, run 12 \n")

turnover.anc = c(1,1,1,2)
eps.anc = c(1,1,1,2)

pp12 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a=r0b, equal e and q, run 13
cat("run the full model with r0a=r1a=r0b, equal e and q, run 13 \n")

turnover.anc = c(1,1,1,2)
eps.anc = c(1,1,1,1)

pp13 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r=free, e=free, and rates q0b1b=0,q1b0b=0, all other q equals, run 14
cat("run the full model with r=free, e=free, and rates q0b1b=0,q1b0b=0, all other q equals, run 14 \n")

turnover.anc = c(1,2,3,4)
eps.anc = c(1,2,3,4)

pp14 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r=free, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 15
cat("run the full model with r=free, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 15 \n")

turnover.anc = c(1,2,3,4)
eps.anc = c(1,1,1,1)

pp15 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a=r0b, e0a=e1a=e0b, and rates q0b1b=0,q1b0b=0, all other q equals, run 16
cat("run the full model with r0a=r1a=r0b, e0a=e1a=e0b, and rates q0b1b=0,q1b0b=0, all other q equals, run 16 \n")

turnover.anc = c(1,1,1,2)
eps.anc = c(1,1,1,2)

pp16 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a=r0b, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 17
cat("run the full model with r0a=r1a=r0b, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 17 \n")

turnover.anc = c(1,1,1,2)
eps.anc = c(1,1,1,1)

pp17 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with with r0a=r0b, e0a=e0b and q equal, run 18
cat("run the full model with with r0a=r0b, e0a=e0b and q equal, run 18 \n")
turnover.anc = c(1,2,1,3)
eps.anc = c(1,2,1,3)

pp18 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates,root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r0b, e and q equal, run 19
cat("run the full model with r0a=r0b, e and q equal, run 19 \n")

turnover.anc = c(1,2,1,3)
eps.anc = c(1,1,1,1)

pp19 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates,root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r0b, e0a=e0b and rates q0b1b=0,q1b0b=0, all other q equals, run 20
cat("run the full model with r0a=r0b, e0a=e0b and rates q0b1b=0,q1b0b=0, all other q equals, run 20 \n")

turnover.anc = c(1,2,1,3)
eps.anc = c(1,2,1,3)

pp20 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r0b, e equals and rates q0b1b=0,q1b0b=0, all other q equals, run 21
cat("run the full model with r0a=r0b, e equals and rates q0b1b=0,q1b0b=0, all other q equals, run 21 \n")

turnover.anc = c(1,2,1,3)
eps.anc = c(1,1,1,1)

pp21 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with q equal, and turnover 0a=1a, and e0a=e1a, run 22
cat("run the full model with q equal, and turnover 0a=1a, and e0a=e1a, run 22 \n")

turnover.anc = c(1,1,2,3)
eps.anc = c(1,1,2,3)

pp22 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a, e and q equal, run 23
cat("run the full model with r0a=r1a, e and q equal, run 23 \n")

turnover.anc = c(1,1,2,3)
eps.anc = c(1,1,1,1)

pp23 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.equalrates, root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a, e0a=e1b, and rates q0b1b=0,q1b0b=0, all other q equals, run 24
cat("run the full model with r0a=r1a, e0a=e1b, and rates q0b1b=0,q1b0b=0, all otherq  equals, run 24 \n")

turnover.anc = c(1,1,2,3)
eps.anc = c(1,1,2,3)

pp24 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates,root.type = "herr_als", output.type="raw")

###################################################################################
#####run the full model with r0a=r1a, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 25
cat("run the full model with r0a=r1a, e equal, and rates q0b1b=0,q1b0b=0, all other q equals, run 25 \n")

turnover.anc = c(1,1,2,3)
eps.anc = c(1,1,1,1)

pp25 = hisse.old(mytree, states, f=c(0.59,0.59), hidden.states=TRUE, turnover.anc=turnover.anc, 
                 eps.anc=eps.anc, trans.rate=trans.rates.nodual.threerates,root.type = "herr_als", output.type="raw")


#######################################################################
#Do the AIC weights

# AIC weight
aics <- data.frame(c("model1", "model2", "model3", "model4","model5","model6","model7","model8","model9","model10","model11","model12",
                     "model13","model14","model15","model16","model17","model18","model19","model20","model21","model22","model23","model24","model25"), 
                   c(pp01$loglik,pp02$loglik,pp03$loglik,pp04$loglik,pp05$loglik,pp06$loglik,pp07$loglik,pp08$loglik,
                     pp09$loglik,pp10$loglik,pp11$loglik,pp12$loglik,pp13$loglik,pp14$loglik,pp15$loglik,pp16$loglik,
                     pp17$loglik,pp18$loglik,pp19$loglik,pp20$loglik,pp21$loglik,pp22$loglik,pp23$loglik,pp24$loglik,pp25$loglik),
                   c(pp01$AICc,pp02$AICc,pp03$AICc,pp04$AICc,pp05$AICc,pp06$AICc,pp07$AICc,pp08$AICc,
                     pp09$AICc,pp10$AICc,pp11$AICc,pp12$AICc,pp13$AICc,pp14$AICc,pp15$AICc,pp16$AICc,
                     pp17$AICc,pp18$AICc,pp19$AICc,pp20$AICc,pp21$AICc,pp22$AICc,pp23$AICc,pp24$AICc,pp25$AICc), 
                   row.names = NULL)
colnames(aics) <- c("model", "loglik", "AICc")
aics
aics <- aics[order(aics$AICc), ]

for(i in 1:dim(aics)[1]){ 
  aics$delta[i] <- aics$AICc[i] - aics$AICc[1]
} 
aics$W <- (exp(-0.5 * aics$delta) / sum(exp(-0.5 * aics$delta)))
aics
write.table(format(aics, digits = 5, scientific=FALSE), file="filename.txt", sep = "\t", row.names = FALSE, quote = FALSE)

#######################################################################

#######################################################################
#perform character reconstructions (using the same root prior with monchromatic = 1, dichromatic = 0)

pp <- MarginRecon.old(pp01$phy, pp01$data, f=pp01$f, pars=pp01$solution, hidden.states=pp01$hidden.states, AIC=pp01$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.1.recon_rootherr.Rsave")

##BiSSE-model
pp <- MarginRecon.old(pp02$phy, pp02$data, f=pp02$f, pars=pp02$solution, hidden.states=pp02$hidden.states, AIC=pp02$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.2.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp03$phy, pp03$data, f=pp03$f, pars=pp03$solution, hidden.states=pp03$hidden.states, AIC=pp03$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.3.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp04$phy, pp04$data, f=pp04$f, pars=pp04$solution, hidden.states=pp04$hidden.states, AIC=pp04$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.4.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp05$phy, pp05$data, f=pp05$f, pars=pp05$solution, hidden.states=pp05$hidden.states, AIC=pp05$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.5.recon_rootherr.Rsave")

##Null-2
pp <- MarginRecon.old(pp06$phy, pp06$data, f=pp06$f, pars=pp06$solution, hidden.states=pp06$hidden.states, AIC=pp06$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.6.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp07$phy, pp07$data, f=pp07$f, pars=pp07$solution, hidden.states=pp07$hidden.states, AIC=pp07$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.7.recon_rootherr.Rsave")

##Null-4
pp <- MarginRecon.old(pp08$phy, pp08$data, f=pp08$f, pars=pp08$solution, four.state.null=TRUE, AIC=pp08$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.8.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp09$phy, pp09$data, f=pp09$f, pars=pp09$solution, four.state.null=TRUE, AIC=pp09$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.9.recon_rootherr.Rsave")

#HiSSE set
pp <- MarginRecon.old(pp10$phy, pp10$data, f=pp10$f, pars=pp10$solution, hidden.states=pp10$hidden.states, AIC=pp10$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.10.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp11$phy, pp11$data, f=pp11$f, pars=pp11$solution, hidden.states=pp11$hidden.states, AIC=pp11$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.11.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp12$phy, pp12$data, f=pp12$f, pars=pp12$solution, hidden.states=pp12$hidden.states,AIC=pp12$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.12.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp13$phy, pp13$data, f=pp13$f, pars=pp13$solution, hidden.states=pp13$hidden.states, AIC=pp13$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.13.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp14$phy, pp14$data, f=pp14$f, pars=pp14$solution, hidden.states=pp14$hidden.states, AIC=pp14$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.14.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp15$phy, pp15$data, f=pp15$f, pars=pp15$solution, hidden.states=pp15$hidden.states, AIC=pp15$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.15.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp16$phy, pp16$data, f=pp16$f, pars=pp16$solution, hidden.states=pp16$hidden.states, AIC=pp16$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.16.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp17$phy, pp17$data, f=pp17$f, pars=pp17$solution, hidden.states=pp17$hidden.states, AIC=pp17$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.17.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp18$phy, pp18$data, f=pp18$f, pars=pp18$solution, hidden.states=pp18$hidden.states, AIC=pp18$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.18.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp19$phy, pp19$data, f=pp19$f, pars=pp19$solution, hidden.states=pp19$hidden.states, AIC=pp19$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.19.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp20$phy, pp20$data, f=pp20$f, pars=pp20$solution, hidden.states=pp20$hidden.states, AIC=pp20$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.20.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp21$phy, pp21$data, f=pp21$f, pars=pp21$solution, hidden.states=pp21$hidden.states, AIC=pp21$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.21.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp22$phy, pp22$data, f=pp22$f, pars=pp22$solution, hidden.states=pp22$hidden.states, AIC=pp22$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.22.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp23$phy, pp23$data, f=pp23$f, pars=pp23$solution, hidden.states=pp23$hidden.states, AIC=pp23$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.23.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp24$phy, pp24$data, f=pp24$f, pars=pp24$solution, hidden.states=pp24$hidden.states, AIC=pp24$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.24.recon_rootherr.Rsave")

pp <- MarginRecon.old(pp25$phy, pp25$data, f=pp25$f, pars=pp25$solution, hidden.states=pp25$hidden.states, AIC=pp25$AIC, 
                      root.type = "herr_als")
save(pp, file="Aspidistra.model.25.recon_rootherr.Rsave")


#######################################################################
#Do the plots using Sean's "plot.hisse.states.PIES" R script

#1 HiSSE: all τ different; all ε different; all q’s different "full"
model1 <- load("Aspidistra.model.1.recon_rootherr.Rsave")
pdf(file="filename.pdf", 20, 20)
plot.hisse.states.PIES(pp, rate.param = "net.div", type = "fan", fsize = 0.4, edge.width.rate=4, edge.width.state=2, tip.pie.size=0.2, node.pie.size=0.3)
dev.off()

#######################################################################
#Do a model averaged plot, incorporating all reconstruction results by weight

hisse.list = list()
models <- system(paste("ls -1 ", "Aspidistra.model.", "*.recon_rootherr.Rsave", sep=""), intern=TRUE)
for(i in 1:length(models)){
  load(models[i])
  hisse.list[[i]] = pp
  rm(pp)
}
hisse.list

pdf(file="file name", 20, 20)
plot.hisse.states(hisse.list, rate.param="net.div", type = "fan", show.tip.label=TRUE, legend="all",
                  fsize=0.5, do.observed.only=TRUE, rate.colors=c("steelblue","tomato"),edge.width.rate=5, 
                  edge.width.state=3, tip.pie.size=0.5)
dev.off()

models_aver<- GetModelAveRates(hisse.list, type = "tips")
save(models_aver, file="filename.RData")
write.table(models_aver, file="filename.txt")

#after combinging state calls into one new column called states
rates <- read.table("filename.txt", header=TRUE)

pdf(file="filename")
boxplot(rates$net.div~rates$state, boxwex=0.5, 
        notch = TRUE, main="Net Diversification",
        col = c("steelblue","tomato"), 
        xlab="not mushroom shaped vs. mushroom shaped", ylab="Diversification rate")
dev.off()

#######################################################################

