##this script is modified from Moen (2020) by Lihua Yang
###Moen D. 2020. Improving inference and avoiding overinterpretation of hidden-state diversification models: Specialized plant breeding has no effect on diversification in frogs. Evolution 76: 373-384.

# Load relevant libraries
library(ape)
library(phangorn)
library(diversitree)
library(phytools)
library(geiger)
library(nlme)

setwd("set your work path")

#need the R script traitDependent_functions.R to complete the run
source("traitDependent_functions.R")

### Load data and functions
mytree <- read.tree("tree file")
mydata <- read.csv("trait file", row.names = 1)

#######################################################################
#compares names between the tree and the data to list any discrepancies
comparison <- name.check(phy=mytree,data=mydata)
comparison

#######################################################################
# prune taxa that don't have data but are present in the tree
mytree <- drop.tip(mytree,comparison$tree_not_data)
#write.tree(mytree,"Sau_drop.tre")
#double check to make sure that taxa all match with tree and data
name.check(phy=mytree,data=mydata)
#comparison <- name.check(phy=mytree,data=mydata)

#create vector for traits
# if the vector names are changed, then commands following this will need to be altered to maintain the procedure
states <- mydata[,2]
names(states) <- row.names(mydata)


#------- Arguments to FISSE.binary function	
#
#    phy               = class phylo phylogenetic tree
#    states            = vector of state data (must have names attribute)
#    reps              = Number of simulations to perform when generating null distribution
#    tol               = tolerance value to accept simulation as valid
#                           default value of 0.1 means that null simulations will be accepted 
#                           if parsimony-reconstructed changes are +/- 10% of the observed value
#    qratetype         = How to estimate rates for the mk1 simulations of the null distribution. 
#                            default value of mk1 fits a symmetric 1-rate Mk model to the data
#                            option "parsimony" simply divides the number of changes by the summed edge lengths
#                     


### FiSSE analysis
set.seed(2852) # Set random-number seed to ensure reproducibility of simulation-based P-value
FISSE.res <- FISSE.binary(mytree, states, reps=1000)
FISSE.res


# components of returned object:
#
#    lambda0           = inverse splits rate estimate for state 0
#    lambda1           = inverse splits rate estimate for state 1
#    pval              = proportion of simulations where observed test statistic (lambda1 - lambda0)
#                           greater than the simulated value.
#   null_mean_diff     =   average (lambda1 - lambda0) for null distribution           
#   null_sd            =  std deviation of the null distribution
#   nchanges_parsimony = number of parsimony-reconstructed changes in trait values
#   qpars              = transition rate under symmetric (Mk1) model of trait evolution
#	                         (used to simulated null distribution)


### Two-tailed pvalue is obtained as
pval_2tailed   <- min(FISSE.res$pval, 1 - FISSE.res$pval)

