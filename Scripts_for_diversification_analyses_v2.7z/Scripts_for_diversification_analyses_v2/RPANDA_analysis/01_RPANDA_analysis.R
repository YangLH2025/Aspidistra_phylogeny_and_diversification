##this script was modified from Condamine et al. (2018) by Lihua Yang
## Condamine FL, Rolland J, H?hna S, Sperling FAH, Sanmart��n I. 2018. Testing the role of the Red Queen and Court Jester as drivers of the macroevolution of Apollo butterflies. Systematic Biology 67: 940�C964.

#Required R packages and source the R codes and functions

library(picante)
library(pspline)
library(qpcR)


setwd("***") ##set your work path


source("fit_bd.R")
source("fit_env_bd.R")
source("likelihood_bd.R")
source("Phi.R")
source("Psi.R")
source("integrate.R")

####################
## Fit the models ##
####################

posteriors <- read.tree("test12_random1000_ingroup.trees") ###set your test trees
totalsp <- Ntip(posteriors[[0.59]]) ##set your sampling fraction

final_RPANDA<-list()
results_RPANDA<-c()

for (i in 1:length(posteriors))
{
	print(i)
	tree<-posteriors[[i]]
	tot_time<-max(node.age(tree)$ages)
	f<-Ntip(tree)/totalsp
	cond="crown"

######################################################
###### Null models (for model testing purposes) ######
######################################################

# BCST (Pure birth)
print("BCST")
f.lamb<-function(x,y){y[1]}
f.mu<-function(x,y){0}
lamb_par<-c(0.1)
mu_par<-c()
cst.lamb=T; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T

	model_BCST<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCST)

# BCST DCST (constant Birth-death)
print("BCST DCST")
f.lamb<-function(x,y){y[1]}
f.mu<-function(x,y){y[1]}
lamb_par<-c(model_BCST$lamb_par[1])
mu_par<-c(0.01)
cst.lamb=T; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BCSTDCST<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCSTDCST)

#####################################################
###### Time Dependence (exponential variation) ######
#####################################################

	print(i)
	
# BTimeVar EXPO
print("BTimeVar EXPO")
f.lamb<-function(x,y){y[1]*exp(y[2]*x)}
f.mu<-function(x,y){0}
lamb_par<-c(0.1,0.01)
mu_par<-c()
cst.lamb=F; cst.mu=T; expo.lamb=T; expo.mu=F; fix.mu=T

	model_BTimeVar_EXPO<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVar_EXPO)

# BTimeVar DCST EXPO
print("BTimeVar DCST EXPO")
f.lamb<-function(x,y){y[1]*exp(y[2]*x)}
f.mu<-function(x,y){y[1]}
lamb_par<-c(model_BTimeVar_EXPO$lamb_par[1],model_BTimeVar_EXPO$lamb_par[2])
mu_par<-c(0.05)
cst.lamb=F; cst.mu=T; expo.lamb=T; expo.mu=F; fix.mu=F

	model_BTimeVarDCST_EXPO<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVarDCST_EXPO)

# BCST DTimeVar EXPO
print("BCST DTimeVar EXPO")
f.lamb<-function(x,y){y[1]}
f.mu<-function(x,y){y[1]*exp(y[2]*x)}
lamb_par<-c(model_BCSTDCST$lamb_par[1])
mu_par<-c(0.05,0.01)
cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=T; fix.mu=F

	model_BCSTDTimeVar_EXPO<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCSTDTimeVar_EXPO)

# BTimeVar DTimeVar EXPO
print("BTimeVar DTimeVar EXPO")
f.lamb<-function(x,y){y[1]*exp(y[2]*x)}
f.mu<-function(x,y){y[1]*exp(y[2]*x)}
lamb_par<-c(model_BTimeVarDCST_EXPO$lamb_par[1],0.01)
mu_par<-c(0.05,0.01)
cst.lamb=F; cst.mu=F; expo.lamb=T; expo.mu=T; fix.mu=F

	model_BTimeVarDTimeVar_EXPO<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVarDTimeVar_EXPO)

################################################
###### Time Dependence (linear variation) ######
################################################

	print(i)
	
# BTimeVar LIN
print("BTimeVar LIN")
f.lamb<-function(x,y){y[1]+(y[2]*x)}
f.mu<-function(x,y){0}
lamb_par<-c(0.1,0.01)
mu_par<-c()
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T

	model_BTimeVar_LIN<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVar_LIN)

# BTimeVar DCST LIN
print("BTimeVar DCST LIN")
f.lamb<-function(x,y){y[1]+(y[2]*x)}
f.mu<-function(x,y){y[1]}
lamb_par<-c(abs(model_BTimeVar_LIN$lamb_par[1]),model_BTimeVar_LIN$lamb_par[2])
mu_par<-c(0.05)
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BTimeVarDCST_LIN<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVarDCST_LIN)

# BCST DTimeVar LIN
print("BCST DTimeVar LIN")
f.lamb<-function(x,y){y[1]}
f.mu<-function(x,y){y[1]+(y[2]*x)}
lamb_par<-c(model_BCSTDCST$lamb_par[1])
mu_par<-c(0.05,0.01)
cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BCSTDTimeVar_LIN<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCSTDTimeVar_LIN)

# BTimeVar DTimeVar LIN
print("BTimeVar DTimeVar LIN")
f.lamb<-function(x,y){y[1]+(y[2]*x)}
f.mu<-function(x,y){y[1]+(y[2]*x)}
lamb_par<-c(abs(model_BTimeVarDCST_LIN$lamb_par[1]),0.01)
mu_par<-c(0.05,0.01)
cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BTimeVarDTimeVar_LIN<-fit_bd(tree,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BTimeVarDTimeVar_LIN)



########################################################
###### Monsoon Dependence (exponential variation) ######
########################################################

env_data <- read.table("AsianMonsoons.txt",header=T)

	print(i)
	
# BMonsoonVar EXPO
print("BMonsoonVar EXPO")
f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
f.mu<-function(t,x,y){0}
lamb_par<-c(0.1,0.0)
mu_par<-c()
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T

	model_BMonsoonVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVar_EXPO)

# BMonsoonVar DCST EXPO
print("BMonsoonVar DCST EXPO")
f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
f.mu<-function(t,x,y){y[1]}
lamb_par<-c(abs(model_BMonsoonVar_EXPO$lamb_par[1]),model_BMonsoonVar_EXPO$lamb_par[2])
mu_par<-c(0.05)
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BMonsoonVarDCST_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVarDCST_EXPO)

# BCST DMonsoonVar EXPO
print("BCST DMonsoonVar EXPO")
f.lamb<-function(t,x,y){y[1]}
f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
lamb_par<-c(model_BCSTDCST$lamb_par[1])
mu_par<-c(0.05,0.0)
cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BCSTDMonsoonVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCSTDMonsoonVar_EXPO)

# BMonsoonVar DMonsoonVar EXPO
print("BMonsoonVar DMonsoonVar EXPO")
f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
lamb_par<-c(abs(model_BMonsoonVarDCST_EXPO$lamb_par[1]),model_BMonsoonVarDCST_EXPO$lamb_par[2])
mu_par<-c(0.05,0.0)
cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BMonsoonVarDMonsoonVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVarDMonsoonVar_EXPO)


################################################
##### Monsoon Dependence (linear variation) ####
################################################

	print(i)
	
# BMonsoonVar LIN
print("BMonsoonVar LIN")
f.lamb<-function(t,x,y){y[1]+y[2]*x}
f.mu<-function(t,x,y){0}
lamb_par<-c(0.1,0.0)
mu_par<-c()
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T

	model_BMonsoonVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVar_LIN)

# BMonsoonVar DCST LIN
print("BMonsoonVar DCST LIN")
f.lamb<-function(t,x,y){y[1]+y[2]*x}
f.mu<-function(t,x,y){y[1]}
lamb_par<-c(abs(model_BMonsoonVar_LIN$lamb_par[1]),model_BMonsoonVar_LIN$lamb_par[2])
mu_par<-c(0.05)
cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BMonsoonVarDCST_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVarDCST_LIN)

# BCST DMonsoonVar LIN
print("BCST DMonsoonVar LIN")
f.lamb<-function(t,x,y){y[1]}
f.mu<-function(t,x,y){y[1]+y[2]*x}
lamb_par<-c(model_BCSTDCST$lamb_par[1])
mu_par<-c(0.05,0.0)
cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BCSTDMonsoonVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BCSTDMonsoonVar_LIN)

# BMonsoonVar DMonsoonVar LIN
print("BMonsoonVar DMonsoonVar LIN")
f.lamb<-function(t,x,y){y[1]+y[2]*x}
f.mu<-function(t,x,y){y[1]+y[2]*x}
lamb_par<-c(abs(model_BMonsoonVarDCST_LIN$lamb_par[1]),model_BMonsoonVarDCST_LIN$lamb_par[2])
mu_par<-c(0.05,0.0)
cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F

	model_BMonsoonVarDMonsoonVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
	print(model_BMonsoonVarDMonsoonVar_LIN)
	
	
#####################################################
###### Temp Dependence (exponential variation) ######
#####################################################
  
  env_data <- read.table("temperature_2020science.txt",header=T)
  
  print(i)
  
  # BTempVar EXPO
  print("BTempVar EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){0}
  lamb_par<-c(0.1,0.0)
  mu_par<-c()
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T
  
  model_BTempVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVar_EXPO)
  
  # BTempVar DCST EXPO
  print("BTempVar DCST EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){y[1]}
  lamb_par<-c(abs(model_BTempVar_EXPO$lamb_par[1]),model_BTempVar_EXPO$lamb_par[2])
  mu_par<-c(0.05)
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BTempVarDCST_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVarDCST_EXPO)
  
  # BCST DTempVar EXPO
  print("BCST DTempVar EXPO")
  f.lamb<-function(t,x,y){y[1]}
  f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
  lamb_par<-c(model_BCSTDCST$lamb_par[1])
  mu_par<-c(0.05,0.0)
  cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCSTDTempVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCSTDTempVar_EXPO)
  
  # BTempVar DTempVar EXPO
  print("BTempVar DTempVar EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
  lamb_par<-c(abs(model_BTempVarDCST_EXPO$lamb_par[1]),model_BTempVarDCST_EXPO$lamb_par[2])
  mu_par<-c(0.05,0.0)
  cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BTempVarDTempVar_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVarDTempVar_EXPO)
  
  
################################################
###### Temp Dependence (linear variation) ######
################################################
  
  print(i)
  
  # BTempVar LIN
  print("BTempVar LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){0}
  lamb_par<-c(0.1,0.0)
  mu_par<-c()
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T
  
  model_BTempVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVar_LIN)
  
  # BTempVar DCST LIN
  print("BTempVar DCST LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){y[1]}
  lamb_par<-c(abs(model_BTempVar_LIN$lamb_par[1]),model_BTempVar_LIN$lamb_par[2])
  mu_par<-c(0.05)
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BTempVarDCST_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVarDCST_LIN)
  
  # BCST DTempVar LIN
  print("BCST DTempVar LIN")
  f.lamb<-function(t,x,y){y[1]}
  f.mu<-function(t,x,y){y[1]+y[2]*x}
  lamb_par<-c(model_BCSTDCST$lamb_par[1])
  mu_par<-c(0.05,0.0)
  cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCSTDTempVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCSTDTempVar_LIN)
  
  # BTempVar DTempVar LIN
  print("BTempVar DTempVar LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){y[1]+y[2]*x}
  lamb_par<-c(abs(model_BTempVarDCST_LIN$lamb_par[1]),model_BTempVarDCST_LIN$lamb_par[2])
  mu_par<-c(0.05,0.0)
  cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BTempVarDTempVar_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BTempVarDTempVar_LIN)


#####################################################
###### CO2 Dependence (exponential variation) ######
#####################################################
  
  env_data <- read.table("CO2_level.txt",header=T)
  
  print(i)
  
  # BCO2Var EXPO
  print("BCO2Var EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){0}
  lamb_par<-c(0.1,0.0)
  mu_par<-c()
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T
  
  model_BCO2Var_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2Var_EXPO)
  
  # BCO2Var DCST EXPO
  print("BCO2Var DCST EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){y[1]}
  lamb_par<-c(abs(model_BCO2Var_EXPO$lamb_par[1]),model_BCO2Var_EXPO$lamb_par[2])
  mu_par<-c(0.05)
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCO2VarDCST_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2VarDCST_EXPO)
  
  # BCST DCO2Var EXPO
  print("BCST DCO2Var EXPO")
  f.lamb<-function(t,x,y){y[1]}
  f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
  lamb_par<-c(model_BCSTDCST$lamb_par[1])
  mu_par<-c(0.05,0.0)
  cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCSTDCO2Var_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCSTDCO2Var_EXPO)
  
  # BCO2Var DCO2Var EXPO
  print("BCO2Var DCO2Var EXPO")
  f.lamb<-function(t,x,y){y[1]*exp(y[2]*x)}
  f.mu<-function(t,x,y){y[1]*exp(y[2]*x)}
  lamb_par<-c(abs(model_BCO2VarDCST_EXPO$lamb_par[1]),model_BCO2VarDCST_EXPO$lamb_par[2])
  mu_par<-c(0.05,0.0)
  cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCO2VarDCO2Var_EXPO<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2VarDCO2Var_EXPO)
  
  
  ################################################
  ###### CO2 Dependence (linear variation) ######
  ################################################
  
  print(i)
  
  # BCO2Var LIN
  print("BCO2Var LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){0}
  lamb_par<-c(0.1,0.0)
  mu_par<-c()
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=T
  
  model_BCO2Var_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2Var_LIN)
  
  # BCO2Var DCST LIN
  print("BCO2Var DCST LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){y[1]}
  lamb_par<-c(abs(model_BCO2Var_LIN$lamb_par[1]),model_BCO2Var_LIN$lamb_par[2])
  mu_par<-c(0.05)
  cst.lamb=F; cst.mu=T; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCO2VarDCST_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2VarDCST_LIN)
  
  # BCST DCO2Var LIN
  print("BCST DCO2Var LIN")
  f.lamb<-function(t,x,y){y[1]}
  f.mu<-function(t,x,y){y[1]+y[2]*x}
  lamb_par<-c(model_BCSTDCST$lamb_par[1])
  mu_par<-c(0.05,0.0)
  cst.lamb=T; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCSTDCO2Var_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCSTDCO2Var_LIN)
  
  # BCO2Var DCO2Var LIN
  print("BCO2Var DCO2Var LIN")
  f.lamb<-function(t,x,y){y[1]+y[2]*x}
  f.mu<-function(t,x,y){y[1]+y[2]*x}
  lamb_par<-c(abs(model_BCO2VarDCST_LIN$lamb_par[1]),model_BCO2VarDCST_LIN$lamb_par[2])
  mu_par<-c(0.05,0.0)
  cst.lamb=F; cst.mu=F; expo.lamb=F; expo.mu=F; fix.mu=F
  
  model_BCO2VarDCO2Var_LIN<-fit_env_bd(tree,env_data,tot_time,f.lamb,f.mu,lamb_par,mu_par,f=f,cst.lamb=cst.lamb,cst.mu=cst.mu,expo.lamb=expo.lamb,expo.mu=expo.mu,fix.mu=fix.mu,cond=cond)
  print(model_BCO2VarDCO2Var_LIN)



###################################
############# RESULTS #############
###################################

	results<-matrix(NA,34,10)
	colnames(results)<-c("Models","Rate_variation","NP","logL","AICc","Akaike_w","Lambda","Alpha","Mu","Beta")

#Models
	results[,1]<-c("BCST","BCSTDCST",
	"BTimeVar_EXPO","BTimeVarDCST_EXPO","BCSTDTimeVar_EXPO","BTimeVarDTimeVar_EXPO","BTimeVar_LIN","BTimeVarDCST_LIN","BCSTDTimeVar_LIN","BTimeVarDTimeVar_LIN",
"BMonsoonVar_EXPO","BMonsoonVarDCST_EXPO","BCSTDMonsoonVar_EXPO","BMonsoonVarDMonsoonVar_EXPO","BMonsoonVar_LIN","BMonsoonVarDCST_LIN","BCSTDMonsoonVar_LIN","BMonsoonVarDMonsoonVar_LIN",

"BTempVar_EXPO","BTempVarDCST_EXPO","BCSTDTempVar_EXPO","BTempVarDTempVar_EXPO","BTempVar_LIN","BTempVarDCST_LIN","BCSTDTempVar_LIN","BTempVarDTempVar_LIN",
"BCO2Var_EXPO","BCO2VarDCST_EXPO","BCSTDCO2Var_EXPO","BCO2VarDCO2Var_EXPO","BCO2Var_LIN","BCO2VarDCST_LIN","BCSTDCO2Var_LIN","BCO2VarDCO2Var_LIN")

#Rate variation
	results[,2]<-c("constant","constant",
	"exponential","exponential","exponential","exponential","linear","linear","linear","linear",
        "exponential","exponential","exponential","exponential","linear","linear","linear","linear",
	"exponential","exponential","exponential","exponential","linear","linear","linear","linear",
        "exponential","exponential","exponential","exponential","linear","linear","linear","linear")

#Parameters
	results[1,3]<-1
	results[2,3]<-2
	results[3,3]<-2
	results[4,3]<-3
	results[5,3]<-3
	results[6,3]<-4
	results[7,3]<-2
	results[8,3]<-3
	results[9,3]<-3
	results[10,3]<-4
	results[11,3]<-2
	results[12,3]<-3
	results[13,3]<-3
	results[14,3]<-4
	results[15,3]<-2
	results[16,3]<-3
	results[17,3]<-3
	results[18,3]<-4
	results[19,3]<-2
	results[20,3]<-3
	results[21,3]<-3
	results[22,3]<-4
	results[23,3]<-2
	results[24,3]<-3
	results[25,3]<-3
	results[26,3]<-4
	results[27,3]<-2
	results[28,3]<-3
	results[29,3]<-3
	results[30,3]<-4
	results[31,3]<-2
	results[32,3]<-3
	results[33,3]<-3
	results[34,3]<-4
	
#logL
	results[1,4]<-round(model_BCST$LH,3)
	results[2,4]<-round(model_BCSTDCST$LH,3)
	results[3,4]<-round(model_BTimeVar_EXPO$LH,3)
	results[4,4]<-round(model_BTimeVarDCST_EXPO$LH,3)
	results[5,4]<-round(model_BCSTDTimeVar_EXPO$LH,3)
	results[6,4]<-round(model_BTimeVarDTimeVar_EXPO$LH,3)
	results[7,4]<-round(model_BTimeVar_LIN$LH,3)
	results[8,4]<-round(model_BTimeVarDCST_LIN$LH,3)
	results[9,4]<-round(model_BCSTDTimeVar_LIN$LH,3)
	results[10,4]<-round(model_BTimeVarDTimeVar_LIN$LH,3)
	results[11,4]<-round(model_BMonsoonVar_EXPO$LH,3)
	results[12,4]<-round(model_BMonsoonVarDCST_EXPO$LH,3)
	results[13,4]<-round(model_BCSTDMonsoonVar_EXPO$LH,3)
	results[14,4]<-round(model_BMonsoonVarDMonsoonVar_EXPO$LH,3)
	results[15,4]<-round(model_BMonsoonVar_LIN$LH,3)
	results[16,4]<-round(model_BMonsoonVarDCST_LIN$LH,3)
	results[17,4]<-round(model_BCSTDMonsoonVar_LIN$LH,3)
	results[18,4]<-round(model_BMonsoonVarDMonsoonVar_LIN$LH,3)
	results[19,4]<-round(model_BTempVar_EXPO$LH,3)
	results[20,4]<-round(model_BTempVarDCST_EXPO$LH,3)
	results[21,4]<-round(model_BCSTDTempVar_EXPO$LH,3)
	results[22,4]<-round(model_BTempVarDTempVar_EXPO$LH,3)
	results[23,4]<-round(model_BTempVar_LIN$LH,3)
	results[24,4]<-round(model_BTempVarDCST_LIN$LH,3)
	results[25,4]<-round(model_BCSTDTempVar_LIN$LH,3)
	results[26,4]<-round(model_BTempVarDTempVar_LIN$LH,3)
	results[27,4]<-round(model_BCO2Var_EXPO$LH,3)
	results[28,4]<-round(model_BCO2VarDCST_EXPO$LH,3)
	results[29,4]<-round(model_BCSTDCO2Var_EXPO$LH,3)
	results[30,4]<-round(model_BCO2VarDCO2Var_EXPO$LH,3)
	results[31,4]<-round(model_BCO2Var_LIN$LH,3)
	results[32,4]<-round(model_BCO2VarDCST_LIN$LH,3)
	results[33,4]<-round(model_BCSTDCO2Var_LIN$LH,3)
	results[34,4]<-round(model_BCO2VarDCO2Var_LIN$LH,3)

#AICc
	results[1,5]<-round(model_BCST$aicc,3)
	results[2,5]<-round(model_BCSTDCST$aicc,3)
	results[3,5]<-round(model_BTimeVar_EXPO$aicc,3)
	results[4,5]<-round(model_BTimeVarDCST_EXPO$aicc,3)
	results[5,5]<-round(model_BCSTDTimeVar_EXPO$aicc,3)
	results[6,5]<-round(model_BTimeVarDTimeVar_EXPO$aicc,3)
	results[7,5]<-round(model_BTimeVar_LIN$aicc,3)
	results[8,5]<-round(model_BTimeVarDCST_LIN$aicc,3)
	results[9,5]<-round(model_BCSTDTimeVar_LIN$aicc,3)
	results[10,5]<-round(model_BTimeVarDTimeVar_LIN$aicc,3)
	results[11,5]<-round(model_BMonsoonVar_EXPO$aicc,3)
	results[12,5]<-round(model_BMonsoonVarDCST_EXPO$aicc,3)
	results[13,5]<-round(model_BCSTDMonsoonVar_EXPO$aicc,3)
	results[14,5]<-round(model_BMonsoonVarDMonsoonVar_EXPO$aicc,3)
	results[15,5]<-round(model_BMonsoonVar_LIN$aicc,3)
	results[16,5]<-round(model_BMonsoonVarDCST_LIN$aicc,3)
	results[17,5]<-round(model_BCSTDMonsoonVar_LIN$aicc,3)
	results[18,5]<-round(model_BMonsoonVarDMonsoonVar_LIN$aicc,3)
	results[19,5]<-round(model_BTempVar_EXPO$aicc,3)
	results[20,5]<-round(model_BTempVarDCST_EXPO$aicc,3)
	results[21,5]<-round(model_BCSTDTempVar_EXPO$aicc,3)
	results[22,5]<-round(model_BTempVarDTempVar_EXPO$aicc,3)
	results[23,5]<-round(model_BTempVar_LIN$aicc,3)
	results[24,5]<-round(model_BTempVarDCST_LIN$aicc,3)
	results[25,5]<-round(model_BCSTDTempVar_LIN$aicc,3)
	results[26,5]<-round(model_BTempVarDTempVar_LIN$aicc,3)
	results[27,5]<-round(model_BCO2Var_EXPO$aicc,3)
	results[28,5]<-round(model_BCO2VarDCST_EXPO$aicc,3)
	results[29,5]<-round(model_BCSTDCO2Var_EXPO$aicc,3)
	results[30,5]<-round(model_BCO2VarDCO2Var_EXPO$aicc,3)
	results[31,5]<-round(model_BCO2Var_LIN$aicc,3)
	results[32,5]<-round(model_BCO2VarDCST_LIN$aicc,3)
	results[33,5]<-round(model_BCSTDCO2Var_LIN$aicc,3)
	results[34,5]<-round(model_BCO2VarDCO2Var_LIN$aicc,3)



#Akaike weights
	all_AICc<-c(
	model_BCST$aicc,model_BCSTDCST$aicc,
	model_BTimeVar_EXPO$aicc,model_BTimeVarDCST_EXPO$aicc,model_BCSTDTimeVar_EXPO$aicc,model_BTimeVarDTimeVar_EXPO$aicc,model_BTimeVar_LIN$aicc,model_BTimeVarDCST_LIN$aicc,model_BCSTDTimeVar_LIN$aicc,model_BTimeVarDTimeVar_LIN$aicc,
	model_BMonsoonVar_EXPO$aicc,model_BMonsoonVarDCST_EXPO$aicc,model_BCSTDMonsoonVar_EXPO$aicc,model_BMonsoonVarDMonsoonVar_EXPO$aicc,model_BMonsoonVar_LIN$aicc,model_BMonsoonVarDCST_LIN$aicc,model_BCSTDMonsoonVar_LIN$aicc,model_BMonsoonVarDMonsoonVar_LIN$aicc,
        model_BTempVar_EXPO$aicc,model_BTempVarDCST_EXPO$aicc,model_BCSTDTempVar_EXPO$aicc,model_BTempVarDTempVar_EXPO$aicc,model_BTempVar_LIN$aicc,model_BTempVarDCST_LIN$aicc,model_BCSTDTempVar_LIN$aicc,model_BTempVarDTempVar_LIN$aicc,
	model_BCO2Var_EXPO$aicc,model_BCO2VarDCST_EXPO$aicc,model_BCSTDCO2Var_EXPO$aicc,model_BCO2VarDCO2Var_EXPO$aicc,model_BCO2Var_LIN$aicc,model_BCO2VarDCST_LIN$aicc,model_BCSTDCO2Var_LIN$aicc,model_BCO2VarDCO2Var_LIN$aicc)
	akaike.weights(all_AICc)
	results[1,6]<-round(akaike.weights(all_AICc)$weights[1],3)
	results[2,6]<-round(akaike.weights(all_AICc)$weights[2],3)
	results[3,6]<-round(akaike.weights(all_AICc)$weights[3],3)
	results[4,6]<-round(akaike.weights(all_AICc)$weights[4],3)
	results[5,6]<-round(akaike.weights(all_AICc)$weights[5],3)
	results[6,6]<-round(akaike.weights(all_AICc)$weights[6],3)
	results[7,6]<-round(akaike.weights(all_AICc)$weights[7],3)
	results[8,6]<-round(akaike.weights(all_AICc)$weights[8],3)
	results[9,6]<-round(akaike.weights(all_AICc)$weights[9],3)
	results[10,6]<-round(akaike.weights(all_AICc)$weights[10],3)
	results[11,6]<-round(akaike.weights(all_AICc)$weights[11],3)
	results[12,6]<-round(akaike.weights(all_AICc)$weights[12],3)
	results[13,6]<-round(akaike.weights(all_AICc)$weights[13],3)
	results[14,6]<-round(akaike.weights(all_AICc)$weights[14],3)
	results[15,6]<-round(akaike.weights(all_AICc)$weights[15],3)
	results[16,6]<-round(akaike.weights(all_AICc)$weights[16],3)
	results[17,6]<-round(akaike.weights(all_AICc)$weights[17],3)
	results[18,6]<-round(akaike.weights(all_AICc)$weights[18],3)
	results[19,6]<-round(akaike.weights(all_AICc)$weights[19],3)
	results[20,6]<-round(akaike.weights(all_AICc)$weights[20],3)
	results[21,6]<-round(akaike.weights(all_AICc)$weights[21],3)
	results[22,6]<-round(akaike.weights(all_AICc)$weights[22],3)
	results[23,6]<-round(akaike.weights(all_AICc)$weights[23],3)
	results[24,6]<-round(akaike.weights(all_AICc)$weights[24],3)
	results[25,6]<-round(akaike.weights(all_AICc)$weights[25],3)
	results[26,6]<-round(akaike.weights(all_AICc)$weights[26],3)
	results[27,6]<-round(akaike.weights(all_AICc)$weights[27],3)
	results[28,6]<-round(akaike.weights(all_AICc)$weights[28],3)
	results[29,6]<-round(akaike.weights(all_AICc)$weights[29],3)
	results[30,6]<-round(akaike.weights(all_AICc)$weights[30],3)
	results[31,6]<-round(akaike.weights(all_AICc)$weights[31],3)
	results[32,6]<-round(akaike.weights(all_AICc)$weights[32],3)
	results[33,6]<-round(akaike.weights(all_AICc)$weights[33],3)
	results[34,6]<-round(akaike.weights(all_AICc)$weights[34],3)

	
#Lambda0
	results[1,7]<-round(abs(model_BCST$lamb_par[1]),4)
	results[2,7]<-round(abs(model_BCSTDCST$lamb_par[1]),4)
	results[3,7]<-round(abs(model_BTimeVar_EXPO$lamb_par[1]),4)
	results[4,7]<-round(abs(model_BTimeVarDCST_EXPO$lamb_par[1]),4)
	results[5,7]<-round(abs(model_BCSTDTimeVar_EXPO$lamb_par[1]),4)
	results[6,7]<-round(abs(model_BTimeVarDTimeVar_EXPO$lamb_par[1]),4)
	results[7,7]<-round(abs(model_BTimeVar_LIN$lamb_par[1]),4)
	results[8,7]<-round(abs(model_BTimeVarDCST_LIN$lamb_par[1]),4)
	results[9,7]<-round(abs(model_BCSTDTimeVar_LIN$lamb_par[1]),4)
	results[10,7]<-round(abs(model_BTimeVarDTimeVar_LIN$lamb_par[1]),4)
	results[11,7]<-round(abs(model_BMonsoonVar_EXPO$lamb_par[1]),4)
	results[12,7]<-round(abs(model_BMonsoonVarDCST_EXPO$lamb_par[1]),4)
	results[13,7]<-round(abs(model_BCSTDMonsoonVar_EXPO$lamb_par[1]),4)
	results[14,7]<-round(abs(model_BMonsoonVarDMonsoonVar_EXPO$lamb_par[1]),4)
	results[15,7]<-round(abs(model_BMonsoonVar_LIN$lamb_par[1]),4)
	results[16,7]<-round(abs(model_BMonsoonVarDCST_LIN$lamb_par[1]),4)
	results[17,7]<-round(abs(model_BCSTDMonsoonVar_LIN$lamb_par[1]),4)
	results[18,7]<-round(abs(model_BMonsoonVarDMonsoonVar_LIN$lamb_par[1]),4)
	results[19,7]<-round(abs(model_BTempVar_EXPO$lamb_par[1]),4)
	results[20,7]<-round(abs(model_BTempVarDCST_EXPO$lamb_par[1]),4)
	results[21,7]<-round(abs(model_BCSTDTempVar_EXPO$lamb_par[1]),4)
	results[22,7]<-round(abs(model_BTempVarDTempVar_EXPO$lamb_par[1]),4)
	results[23,7]<-round(abs(model_BTempVar_LIN$lamb_par[1]),4)
	results[24,7]<-round(abs(model_BTempVarDCST_LIN$lamb_par[1]),4)
	results[25,7]<-round(abs(model_BCSTDTempVar_LIN$lamb_par[1]),4)
	results[26,7]<-round(abs(model_BTempVarDTempVar_LIN$lamb_par[1]),4)
	results[27,7]<-round(abs(model_BCO2Var_EXPO$lamb_par[1]),4)
	results[28,7]<-round(abs(model_BCO2VarDCST_EXPO$lamb_par[1]),4)
	results[29,7]<-round(abs(model_BCSTDCO2Var_EXPO$lamb_par[1]),4)
	results[30,7]<-round(abs(model_BCO2VarDCO2Var_EXPO$lamb_par[1]),4)
	results[31,7]<-round(abs(model_BCO2Var_LIN$lamb_par[1]),4)
	results[32,7]<-round(abs(model_BCO2VarDCST_LIN$lamb_par[1]),4)
	results[33,7]<-round(abs(model_BCSTDCO2Var_LIN$lamb_par[1]),4)
	results[34,7]<-round(abs(model_BCO2VarDCO2Var_LIN$lamb_par[1]),4)


#Alpha
	results[3,8]<-round(model_BTimeVar_EXPO$lamb_par[2],4)
	results[4,8]<-round(model_BTimeVarDCST_EXPO$lamb_par[2],4)
	results[6,8]<-round(model_BTimeVarDTimeVar_EXPO$lamb_par[2],4)
	results[7,8]<-round(model_BTimeVar_LIN$lamb_par[2],4)
	results[8,8]<-round(model_BTimeVarDCST_LIN$lamb_par[2],4)
	results[10,8]<-round(model_BTimeVarDTimeVar_LIN$lamb_par[2],4)
	results[11,8]<-round(model_BMonsoonVar_EXPO$lamb_par[2],4)
	results[12,8]<-round(model_BMonsoonVarDCST_EXPO$lamb_par[2],4)
	results[14,8]<-round(model_BMonsoonVarDMonsoonVar_EXPO$lamb_par[2],4)
	results[15,8]<-round(model_BMonsoonVar_LIN$lamb_par[2],4)
	results[16,8]<-round(model_BMonsoonVarDCST_LIN$lamb_par[2],4)
	results[18,8]<-round(model_BMonsoonVarDMonsoonVar_LIN$lamb_par[2],4)
	results[19,8]<-round(model_BTempVar_EXPO$lamb_par[2],4)
        results[20,8]<-round(model_BTempVarDCST_EXPO$lamb_par[2],4)
        results[22,8]<-round(model_BTempVarDTempVar_EXPO$lamb_par[2],4)
        results[23,8]<-round(model_BTempVar_LIN$lamb_par[2],4)
        results[24,8]<-round(model_BTempVarDCST_LIN$lamb_par[2],4)
        results[26,8]<-round(model_BTempVarDTempVar_LIN$lamb_par[2],4)
	results[27,8]<-round(model_BCO2Var_EXPO$lamb_par[2],4)
	results[28,8]<-round(model_BCO2VarDCST_EXPO$lamb_par[2],4)
	results[30,8]<-round(model_BCO2VarDCO2Var_EXPO$lamb_par[2],4)
	results[31,8]<-round(model_BCO2Var_LIN$lamb_par[2],4)
	results[32,8]<-round(model_BCO2VarDCST_LIN$lamb_par[2],4)
	results[34,8]<-round(model_BCO2VarDCO2Var_LIN$lamb_par[2],4)

#Mu0
	results[2,9]<-round(abs(model_BCSTDCST$mu_par[1]),4)
	results[4,9]<-round(abs(model_BTimeVarDCST_EXPO$mu_par[1]),4)
	results[5,9]<-round(abs(model_BCSTDTimeVar_EXPO$mu_par[1]),4)
	results[6,9]<-round(abs(model_BTimeVarDTimeVar_EXPO$mu_par[1]),4)
	results[8,9]<-round(abs(model_BTimeVarDCST_LIN$mu_par[1]),4)
	results[9,9]<-round(abs(model_BCSTDTimeVar_LIN$mu_par[1]),4)
	results[10,9]<-round(abs(model_BTimeVarDTimeVar_LIN$mu_par[1]),4)
	results[12,9]<-round(abs(model_BMonsoonVarDCST_EXPO$mu_par[1]),4)
	results[13,9]<-round(abs(model_BCSTDMonsoonVar_EXPO$mu_par[1]),4)
	results[14,9]<-round(abs(model_BMonsoonVarDMonsoonVar_EXPO$mu_par[1]),4)
	results[16,9]<-round(abs(model_BMonsoonVarDCST_LIN$mu_par[1]),4)
	results[17,9]<-round(abs(model_BCSTDMonsoonVar_LIN$mu_par[1]),4)
	results[18,9]<-round(abs(model_BMonsoonVarDMonsoonVar_LIN$mu_par[1]),4)
        results[20,9]<-round(abs(model_BTempVarDCST_EXPO$mu_par[1]),4)
	results[21,9]<-round(abs(model_BCSTDTempVar_EXPO$mu_par[1]),4)
	results[22,9]<-round(abs(model_BTempVarDTempVar_EXPO$mu_par[1]),4)
	results[24,9]<-round(abs(model_BTempVarDCST_LIN$mu_par[1]),4)
	results[25,9]<-round(abs(model_BCSTDTempVar_LIN$mu_par[1]),4)
	results[26,9]<-round(abs(model_BTempVarDTempVar_LIN$mu_par[1]),4)
	results[28,9]<-round(abs(model_BCO2VarDCST_EXPO$mu_par[1]),4)
	results[29,9]<-round(abs(model_BCSTDCO2Var_EXPO$mu_par[1]),4)
	results[30,9]<-round(abs(model_BCO2VarDCO2Var_EXPO$mu_par[1]),4)
	results[32,9]<-round(abs(model_BCO2VarDCST_LIN$mu_par[1]),4)
	results[33,9]<-round(abs(model_BCSTDCO2Var_LIN$mu_par[1]),4)
	results[34,9]<-round(abs(model_BCO2VarDCO2Var_LIN$mu_par[1]),4)

	
#Beta
	results[5,10]<-round(model_BCSTDTimeVar_EXPO$mu_par[2],4)
	results[6,10]<-round(model_BTimeVarDTimeVar_EXPO$mu_par[2],4)
	results[9,10]<-round(model_BCSTDTimeVar_LIN$mu_par[2],4)
	results[10,10]<-round(model_BTimeVarDTimeVar_LIN$mu_par[2],4)
	results[13,10]<-round(model_BCSTDMonsoonVar_EXPO$mu_par[2],4)
	results[14,10]<-round(model_BMonsoonVarDMonsoonVar_EXPO$mu_par[2],4)
	results[17,10]<-round(model_BCSTDMonsoonVar_LIN$mu_par[2],4)
	results[18,10]<-round(model_BMonsoonVarDMonsoonVar_LIN$mu_par[2],4)
        results[21,10]<-round(model_BCSTDTempVar_EXPO$mu_par[2],4)
        results[22,10]<-round(model_BTempVarDTempVar_EXPO$mu_par[2],4)
        results[25,10]<-round(model_BCSTDTempVar_LIN$mu_par[2],4)
        results[26,10]<-round(model_BTempVarDTempVar_LIN$mu_par[2],4)
	results[29,10]<-round(model_BCSTDCO2Var_EXPO$mu_par[2],4)
	results[30,10]<-round(model_BCO2VarDCO2Var_EXPO$mu_par[2],4)
	results[33,10]<-round(model_BCSTDCO2Var_LIN$mu_par[2],4)
	results[34,10]<-round(model_BCO2VarDCO2Var_LIN$mu_par[2],4)

	
	final_RPANDA[[i]]<-results

	resi<-list("Clade_age"=tot_time,"Taxon_sampling"=Ntip(tree),"Clade_size"=totalsp,"Sampling_fraction"=f,
	"BCST"=model_BCST,"BCSTDCST"=model_BCSTDCST,
	"BTimeVar_EXPO"=model_BTimeVar_EXPO,"BTimeVarDCST_EXPO"=model_BTimeVarDCST_EXPO,"BCSTDTimeVar_EXPO"=model_BCSTDTimeVar_EXPO,"BTimeVarDTimeVar_EXPO"=model_BTimeVarDTimeVar_EXPO,
	"BTimeVar_LIN"=model_BTimeVar_LIN,"BTimeVarDCST_LIN"=model_BTimeVarDCST_LIN,"BCSTDTimeVar_LIN"=model_BCSTDTimeVar_LIN,"BTimeVarDTimeVar_LIN"=model_BTimeVarDTimeVar_LIN,
	"BMonsoonVar_EXPO"=model_BMonsoonVar_EXPO,"BMonsoonVarDCST_EXPO"=model_BMonsoonVarDCST_EXPO,"BCSTDMonsoonVar_EXPO"=model_BCSTDMonsoonVar_EXPO,"BMonsoonVarDMonsoonVar_EXPO"=model_BMonsoonVarDMonsoonVar_EXPO,"BMonsoonVar_LIN"=model_BMonsoonVar_LIN,"BMonsoonVarDCST_LIN"=model_BMonsoonVarDCST_LIN,"BCSTDMonsoonVar_LIN"=model_BCSTDMonsoonVar_LIN,"BMonsoonVarDMonsoonVar_LIN"=model_BMonsoonVarDMonsoonVar_LIN,

	"BTempVar_EXPO"=model_BTempVar_EXPO,"BTempVarDCST_EXPO"=model_BTempVarDCST_EXPO,"BCSTDTempVar_EXPO"=model_BCSTDTempVar_EXPO,"BTempVarDTempVar_EXPO"=model_BTempVarDTempVar_EXPO,"BTempVar_LIN"=model_BTempVar_LIN,"BTempVarDCST_LIN"=model_BTempVarDCST_LIN,"BCSTDTempVar_LIN"=model_BCSTDTempVar_LIN,"BTempVarDTempVar_LIN"=model_BTempVarDTempVar_LIN,
	"BCO2Var_EXPO"=model_BCO2Var_EXPO,"BCO2VarDCST_EXPO"=model_BCO2VarDCST_EXPO,"BCSTDCO2Var_EXPO"=model_BCSTDCO2Var_EXPO,"BCO2VarDCO2Var_EXPO"=model_BCO2VarDCO2Var_EXPO,"BCO2Var_LIN"=model_BCO2Var_LIN,"BCO2VarDCST_LIN"=model_BCO2VarDCST_LIN,"BCSTDCO2Var_LIN"=model_BCSTDCO2Var_LIN,"BCO2VarDCO2Var_LIN"=model_BCO2VarDCO2Var_LIN)

	results_RPANDA<-c(results_RPANDA,list(resi))
}

for (i in 1:length(posteriors))
{
  write.table(final_RPANDA[[i]], file=paste("Results_RPANDA_ingroup_test20240616_tree", i, ".csv"), quote=FALSE, sep=",", row.names=FALSE)
}

	source("tables.summary.R")
	final_table<-tables.summary(final_RPANDA)

	write.table(final_table, file="Results.txt", quote=FALSE, sep="\t", row.names=FALSE)
	save(results_RPANDA,file="Results_RPANDA.Rdata")


