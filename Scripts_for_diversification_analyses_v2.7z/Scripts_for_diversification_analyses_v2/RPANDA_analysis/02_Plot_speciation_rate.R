##this script was modified from Condamine et al. (2018) by Lihua Yang
## Condamine FL, Rolland J, H?hna S, Sperling FAH, Sanmart��n I. 2018. Testing the role of the Red Queen and Court Jester as drivers of the macroevolution of Apollo butterflies. Systematic Biology 67: 940�C964.

##########################
## Plot Speciation rate ##
##########################
setwd("***") ##set your work path

library(picante)
library(pspline)

pdf("file_name.pdf")

par(mfrow=c(2,3), mar=c(4,4,2,2))

##
## a) Paleo-temprature
##

InfTemp<-read.table("temperature_2020science.txt", header=T)

plot(-InfTemp[,"Age"],InfTemp[,"Temperature"], main="a) Global paleo-temperatures over the last 4.55 Myrs", xlab="", ylab="Relative temperature change", 
     type="p", lwd=0.5, xlim=c(-4.55,0), ylim=c(-6,4), col="grey", las=1, cex.axis=0.8, cex.main=0.8, bty = "l")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(-6, 4, by = 2), las=1, cex.axis=0.8)
temp.spl<-smooth.spline(-InfTemp[,"Age"], InfTemp[,"Temperature"],df=120) #df=207.891
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")
lines(temp.spl, col="cornflowerblue", lwd=2)

##
## b) Paleo-Asian monsoons
##

InfAsianMonso<-read.table("AsianMonsoons.txt", header=T)

plot(-InfAsianMonso[,"Age"],InfAsianMonso[,"Monsoons"], main="b) Asian monsoons change over the last 4.55 Myrs", xlab="", ylab="Relative monsoonal change", 
     type="p", lwd=0.5, xlim=c(-4.55,0), ylim=c(-0.2,1.2), col="grey", las=1, cex.axis=0.8, cex.main=0.8, bty = "l")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(-0.2, 1.2, by = 0.2), las=1, cex.axis=0.8)
monsoon.spl<-sm.spline(-InfAsianMonso[,"Age"], InfAsianMonso[,"Monsoons"],df=80)
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")
lines(monsoon.spl, col="brown1", lwd=2)

##
## c) CO2 concentration
##

InfCO2<-read.table("CO2_level.txt", header=T)

plot(-InfCO2[,"Age"],InfCO2[,"CO2"], main="b) CO2 concentration change over the last 4.55 Myrs", xlab="", ylab="Relative CO2 change", 
     type="p", lwd=0.5, xlim=c(-4.55,0), ylim=c(100,600),  col="grey", las=1, cex.axis=0.8, cex.main=0.8, bty = "l")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(100, 600, by = 100), las=1, cex.axis=0.8)
CO2.spl<-sm.spline(-InfCO2[,"Age"], InfCO2[,"CO2"],df=80)
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")
lines(CO2.spl, col="brown1", lwd=2)


##
## d) Speciation rate and Temperature
##

res<-sm.spline(InfTemp[,"Age"],InfTemp[,"Temperature"],df=40) #df=207.891
Temp_fun<-function(x){predict(res,x)}

TempDep_lamb_par1 <- 3.5881292 ###This and the following three values are from the results from RPANDA
TempDep_lamb_par2 <- 1.1359019

TempDep_lamb_par1_sd <- 0.0685804
TempDep_lamb_par2_sd <- 0.0215092


f.lamb.mean<-function(x){TempDep_lamb_par1+(TempDep_lamb_par2*Temp_fun(x))}
plot(-InfTemp[,"Age"], f.lamb.mean(InfTemp[,"Age"]), ty="l",col="cornflowerblue",xlim=c(-4.55,0), ylim=c(-0.4,6), lwd=2, yaxt="n", 
     main="c) the relationships between speciation and past temperatures", xlab="Time (Myrs ago)",ylab="Speciation rate (event/lineage/Myr)", 
     cex.axis=0.8, cex.main=0.8, bty = "n")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(-0.4, 6, by = 1), las=1, cex.axis=0.8)
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")

f.lamb.low<-function(x){(TempDep_lamb_par1-TempDep_lamb_par1_sd)+((TempDep_lamb_par2-TempDep_lamb_par2_sd)*Temp_fun(x))}
lines(-InfTemp[,"Age"], f.lamb.low(InfTemp[,"Age"]),ty="l",col="cornflowerblue",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")

f.lamb.high<-function(x){(TempDep_lamb_par1+TempDep_lamb_par1_sd)+((TempDep_lamb_par2+TempDep_lamb_par2_sd)*Temp_fun(x))}
lines(-InfTemp[,"Age"], f.lamb.high(InfTemp[,"Age"]),ty="l",col="cornflowerblue",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")


##
## e) Speciation rate and Monsoons
##

res2<-sm.spline(InfAsianMonso[,"Age"],InfAsianMonso[,"Monsoons"],df=25)
Monsoon_fun<-function(x){predict(res2,x)}

MonsoonDep_lamb_par1 <- 0.6671686  ###This and the following three values are from the results from RPANDA
MonsoonDep_lamb_par2 <- 0.2721949

MonsoonDep_lamb_par1_sd <- 0.0109628
MonsoonDep_lamb_par2_sd <- 0.0802432


f.lamb.mean<-function(x){MonsoonDep_lamb_par1+(MonsoonDep_lamb_par2*Monsoon_fun(x))}
plot(-InfAsianMonso[,"Age"], f.lamb.mean(InfAsianMonso[,"Age"]), ty="l",col="brown1",xlim=c(-4.55,0), ylim=c(0.6, 0.9), lwd=2, yaxt="n", 
     main="d) the relationships between speciation and past monsoons", xlab="Time (Myrs ago)",ylab="Speciation rate (event/lineage/Myr)", 
     cex.axis=0.8, cex.main=0.8, bty = "n")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(0.6, 0.9, by = 0.1), las=1, cex.axis=0.8)
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")

f.lamb.low<-function(x){(MonsoonDep_lamb_par1-MonsoonDep_lamb_par1_sd)+((MonsoonDep_lamb_par2-MonsoonDep_lamb_par2_sd)*Monsoon_fun(x))}
lines(-InfAsianMonso[,"Age"], f.lamb.low(InfAsianMonso[,"Age"]),ty="l",col="brown1",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")

f.lamb.high<-function(x){(MonsoonDep_lamb_par1+MonsoonDep_lamb_par1_sd)+((MonsoonDep_lamb_par2+MonsoonDep_lamb_par2_sd)*Monsoon_fun(x))}
lines(-InfAsianMonso[,"Age"], f.lamb.high(InfAsianMonso[,"Age"]),ty="l",col="brown1",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")


##
## f) Speciation rate and CO2
##

res3<-sm.spline(InfCO2[,"Age"],InfCO2[,"CO2"],df=30)
CO2_fun<-function(x){predict(res2,x)}

CO2Dep_lamb_par1 <- 1.2116225  ###This and the following three values are from the results from RPANDA
CO2Dep_lamb_par2 <- -0.0043079

CO2Dep_lamb_par1_sd <- 0.0139609
CO2Dep_lamb_par2_sd <- 0.000176

f.lamb.mean<-function(x){CO2Dep_lamb_par1+(CO2Dep_lamb_par2*CO2_fun(x))}
plot(-InfCO2[,"Age"], f.lamb.mean(InfCO2[,"Age"]), ty="l",col="brown1",xlim=c(-4.55,0), ylim=c(1.0,1.4), lwd=2, yaxt="n", 
     main="d) the relationships between speciation and past CO2 concentration", xlab="Time (Myrs ago)",ylab="Speciation rate (event/lineage/Myr)", 
     cex.axis=0.8, cex.main=0.8, bty = "l")
axis(1, at = seq(-4.5, 0, by = 0.5), las=1, cex.axis=0.8)
axis(2, at = seq(1.0, 1.4, by = 0.1), las=1, cex.axis=0.8)
abline(v=c(-3.6,-2.58,-1.81,-0.78),col="grey",lty="dotted",lwd="1")

f.lamb.low<-function(x){(CO2Dep_lamb_par1-CO2Dep_lamb_par1_sd)+((CO2Dep_lamb_par2-CO2Dep_lamb_par2_sd)*CO2_fun(x))}
lines(-InfCO2[,"Age"], f.lamb.low(InfCO2[,"Age"]),ty="l",col="brown1",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")

f.lamb.high<-function(x){(CO2Dep_lamb_par1+CO2Dep_lamb_par1_sd)+((CO2Dep_lamb_par2+CO2Dep_lamb_par2_sd)*CO2_fun(x))}
lines(-InfCO2[,"Age"], f.lamb.high(InfCO2[,"Age"]),ty="l",col="brown1",xlim=c(-4.55,0),lwd=1,lty="dotted",yaxt="n")

dev.off()

