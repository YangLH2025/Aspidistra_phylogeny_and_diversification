import sys
import geopandas as gpd

shp_file1 = sys.argv[1]
out_file1 = sys.argv[2]

df = gpd.read_file(shp_file1)
df_S = df.area*111194.872221777*111194.872221777/1000000

outfile=open(out_file1,"w")
outfile.write(str(df_S)+"\n")

