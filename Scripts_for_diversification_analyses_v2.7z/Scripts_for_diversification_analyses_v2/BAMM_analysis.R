library(ape)
library(BAMMtools)
library(geiger)
library(phytools)
setwd("set your work path")

tree1 <- read.nexus("file_name", tree.names = NULL, force.multi = FALSE)
tip <- c("T_fungilliformis", "R_carnea", "R_japonica", "C_chinensis", "C_wattii") 
tree2 <- drop.tip(tree1, tip, trim.internal = TRUE, subtree = FALSE, root.edge = 0) ## remove outgroup species
write.tree(tree2, file="file_name")

##Check the prerequesities of the tree
is.ultrametric(tree2)
is.binary(tree2)
min(tree2$edge.length) #check min branch length:

##plot tree toplogy with node name
plot.phylo(tree2,type = "phylogram", x.lim = 5, font = 1, direction = "right")
nodelabels(bg=FALSE,frame="none",adj = c(0.5, -0.5), cex = 0.3)

# now to obtain some parameters for set the control file
setBAMMpriors(tree2, outfile = 'myPriors.txt')

## now set the control file and run ./bamm -c controlfile

#####Assessing MCMC convergence

mcmcout <- read.csv("mcmc_out.txt", header=T)
burnstart <- floor(0.25 * nrow(mcmcout))###discard some as burnin
postburn <- mcmcout[burnstart:nrow(mcmcout), ]

library(coda)
effectiveSize(postburn$N_shifts) ##ESS for the number of shifts, at least 200
effectiveSize(postburn$logLik) ##ESS for the log-likelihood, at least 200
effectiveSize(postburn$logPrior) ##ESS for the log Prior, at least 200

##Visual assessment of MCMC convergence of the BAMM run:
par(mfrow=c(2,2)) ##image arrangement 2*2
plot(mcmcout$logLik, type="l", main="a)", xlab="Generations",ylab="log Likelihood")
plot(mcmcout$N_shifts ~ mcmcout$generation, main="b)", xlab="Generations",ylab="Number of shifts")
plot(postburn$logLik, type="l", main="c)", xlab="Generations",ylab="log Likelihood")
plot(postburn$N_shifts ~ postburn$generation, main="d)", xlab="Generations",ylab="Number of shifts")

### Getting BAMM results
events.data <- read.csv("event_data.txt", header=T)
edata <- getEventData(tree2, events.data, burnin=0.25)

## Analysis of rate shifts
### How many rate shifts

##Compute the posterior probabilities of the models sampled using BAMM
post_probs <- table(postburn$N_shifts) / nrow(postburn)
names(post_probs)
post_probs['X'] / post_probs['Y']

##Summarizing the posterior distribution of the number of shifts using summary methods
shift_probs <- summary(edata)

##Posterior probability of the expected number of rate shifts.
par(mfrow=c(1,2)) ##image arrangement 2*1
plot(post_probs, xlim=c(0,8), main="", ylab="Posterior", xlab="Number of shifts")
plotPrior(mcmcout, expectedNumberOfShifts=1)

### Compute Bayes Factor
bfmat <- computeBayesFactors(mcmcout, expectedNumberOfShifts=1, burnin=0.25)
bfmat[,1]
write.csv(bfmat, file="shift_BayesFactors.csv")


### Mean Phylo rate plot
##Speciation rate through time:
##help(assignColorBreaks)
par(mfrow=c(1,1)) ##image arrangement 1*1
plot.bammdata(edata, spex="s", method = "polar")###Mean lamda phylorate plot
plot.bammdata(edata, tau=0.001, spex="s", method = "phylogram", legend=T, lwd=1.5, logcolor = F, breaksmethod = "linear")###Mean lamda phylorate plot
ratesHistogram(plot.bammdata(edata, tau=0.001, spex="s", legend=T, lwd=1.5), plotBrks = TRUE, xlab = "Speciation rate")
#axis(side = 1, at = c(0, 0.17, 0.175, 0.180, 0.185, 0.190, 0.195, 0.20, 0.205, 0.21, 0.215, 0.3),  cex.axis = 0.75, tcl = NA, mgp = c(0,  0.25, 0))

##Extinction rate through time:
plot.bammdata(edata,  tau=0.001, spex="e", method = "phylogram", legend=T, lwd=1.5, logcolor = F, breaksmethod = "linear") ###Mean mu phylorate plot
plot.bammdata(edata,  tau=0.001, spex="e", method = "polar", legend=T, lwd=1.5, logcolor = F, breaksmethod = "linear") ###Mean mu phylorate plot
ratesHistogram(plot.bammdata(edata, tau=0.001, spex="e", legend=T, lwd=1.5), plotBrks = TRUE, xlab = "Extinction rate")

##Net diversification rate through time:
plot.bammdata(edata,  tau=0.001, spex="netdiv", method = "phylogram", legend=T, lwd=1.5, logcolor = F, breaksmethod = "linear") ###Mean netdiv phylorate plot
plot.bammdata(edata,  tau=0.001, spex="netdiv", method = "polar", legend=T, lwd=1.5, logcolor = F, breaksmethod = "linear") ###Mean netdiv phylorate plot
ratesHistogram(plot.bammdata(edata, tau=0.001, spex="netdiv", legend=T, lwd=1.5), plotBrks = TRUE, xlab = "Net diversification rate")
#axis(side = 1, at = c(0, 0.15, 0.155, 0.16, 0.165, 0.17, 0.175, 0.180),  cex.axis = 0.75, tcl = NA, mgp = c(0,  0.25, 0))


### Bayesian credible sets of shift configurations
css <- credibleShiftSet(edata, expectedNumberOfShifts=1, threshold=5, set.limit = 0.95)
css$number.distinct
summary(css)
plot.credibleshiftset(css, spex="netdiv", BFcriterion=5, border=F, pal="temperature")
plot.credibleshiftset(css, spex="s", BFcriterion=5, border=F, pal="temperature")
plot.credibleshiftset(css, spex="e", BFcriterion=5, border=F, pal="temperature")

### Finding the single best shift configuration
best <- getBestShiftConfiguration(edata, expectedNumberOfShifts=1)
plot.bammdata(best, lwd = 2, legend=T)
addBAMMshifts(best, cex=2.5)







