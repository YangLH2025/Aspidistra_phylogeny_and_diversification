#install.packages('TESS')
library(TESS)
library(devtools)
setwd("set your work path")

tree <- read.tree("tree file")
is.ultrametric(tree)

#using speciation and extinction priors from the initial estimates from BAMM
speciationPriorMu <- 0.211390422666323
speciationPriorSigma <- 0.5

extinctionPriorMu <- 0.211390422666323
extinctionPriorSigma <- 0.5

# Transform the priors on the speciation rate into log space.
speciationRatePriorMean <- log((speciationPriorMu^2)
                               /sqrt(speciationPriorSigma^2+
                                       speciationPriorMu^2))
speciationRatePriorStDev <- sqrt(log(1+speciationPriorSigma^2
                                      /(speciationPriorMu^2)))
# Transform the priors on the extinction rate into log space.
extinctionRatePriorMean <- log((extinctionPriorMu^2)
                               /sqrt(extinctionPriorSigma^2+
                                       extinctionPriorMu^2))
extinctionRatePriorStDev <- sqrt(log(1+extinctionPriorSigma^2
                                      /(extinctionPriorMu^2)))


#Expected survival probability after mass extinction
expectedSurvivalProbability <- 0.5

pMassExtinctionPriorShape2 <- 100
pMassExtinctionPriorShape1 <- - pMassExtinctionPriorShape2 *
  expectedSurvivalProbability /
  (expectedSurvivalProbability - 1)

set.seed(345213)
tess.analysis(tree,
              initialSpeciationRate = speciationPriorMu,
              initialExtinctionRate = extinctionPriorMu,
              empiricalHyperPriors = TRUE,
              empiricalHyperPriorInflation = 10, 
              empiricalHyperPriorForm = c("lognormal"),
              speciationRatePriorMean = speciationRatePriorMean,
              speciationRatePriorStDev = speciationRatePriorStDev,
              extinctionRatePriorMean = extinctionRatePriorMean,
              extinctionRatePriorStDev = extinctionRatePriorStDev,
              estimateNumberRateChanges = TRUE,
              numExpectedRateChanges = 2,
              samplingProbability = 0.59,
              pMassExtinctionPriorShape1 = pMassExtinctionPriorShape1,
              pMassExtinctionPriorShape2 = pMassExtinctionPriorShape2,
              estimateMassExtinctionTimes = TRUE,
              numExpectedMassExtinctions = 2,
              estimateNumberMassExtinctions = TRUE,
              MRCA = TRUE,
              CONDITION = "survival",
              BURNIN = 25000,
              MAX_ITERATIONS = 10000000,
              THINNING = 100,
              OPTIMIZATION_FREQUENCY = 500,
              MAX_TIME = Inf, MIN_ESS = 500,
              ADAPTIVE = TRUE,
              dir = "comet_hyperpriors")

output <- tess.process.output("comet_hyperpriors",
                              numExpectedRateChanges = 2,
                              numExpectedMassExtinctions = 2,
                              burnin=0.25,
                              numIntervals=455,
                              criticalBayesFactors=c(2,6,10))

layout.mat <- matrix(1:9,nrow=3,ncol=3,byrow=TRUE)
layout(layout.mat)
tess.plot.output(output,
                 fig.types = c("speciation rates",
                               "speciation shift times",
                               "speciation Bayes factors",
                               "extinction rates",
                               "extinction shift times",
                               "extinction Bayes factors",
                               "net-diversification rates",
                               "mass extinction Bayes factors",
                               "mass extinction times"),
                 col.alpha=95,
                 las=2)


#check convergence
layout.mat <- matrix(1:12,nrow=4,ncol=3,byrow=TRUE)
layout(layout.mat)
tess.plot.singlechain.diagnostics(output, parameters = c("speciation rates",
                                                         "speciation shift times",
                                                         "extinction rates",
                                                         "extinction shift times",
                                                         "net-diversification rates",
                                                         "mass extinction times"), las=2)

var1 <- effectiveSize(output$numSpeciationCategories)
 
